package dao;

import java.sql.*;
import java.util.*;
import entity.*;
import exception.*;
import util.*;

public class HospitalServiceImpl implements IHospitalService {

    private Connection con;

    public HospitalServiceImpl() 
    {
        con = DBConnection.getConnection();
    }

    @Override
    public Appointment getAppointmentById(int appointmentId)
    {
        Appointment a= null;
        try 
        {
            PreparedStatement stat= con.prepareStatement("select * from Appointment where appointmentId=?");
            stat.setInt(1,appointmentId);
            ResultSet rs= stat.executeQuery();
            if (rs.next())
            {
                a= new Appointment(rs.getInt("appointmentId"), rs.getInt("patientId"), rs.getInt("doctorId"),
                        rs.getString("appointmentDate"), rs.getString("description"));
                
            } 
            
            else 
            {
                System.out.println("Invalid ID. Retrieval FAILED");
            }
        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
        }
        return a;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId)
    {
        List<Appointment> a= new ArrayList<>();
        try {
            PreparedStatement stat= con.prepareStatement("select * from Appointment where patientId=?");
            stat.setInt(1,patientId);
            ResultSet rs= stat.executeQuery();
            while(rs.next()) 
            {
                a.add(new Appointment(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getString(5)));
            }
            if(a.isEmpty()) 
            {
                throw new PatientNumberNotFoundException("Patient ID " + patientId + " cannot be found in DB");
            }
        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
        }
        
        return a;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) 
    {
        List<Appointment> a= new ArrayList<>();
        try {
            PreparedStatement stat= con.prepareStatement("select * from Appointment where doctorId=?");
            stat.setInt(1,doctorId);
            ResultSet rs= stat.executeQuery();
            while(rs.next()) 
            {
                a.add(new Appointment(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getString(5)));
            }
            if(a.isEmpty())
            {
                System.out.println("Doctor ID " + doctorId + " cannot be found in DB");
            }
        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
        }
       
        return a;
    }

    @Override
    public boolean scheduleAppointment(Appointment a) 
    {
        try {
            PreparedStatement stat= con.prepareStatement("insert into Appointment values(?, ?, ?, ?, ?)");
            stat.setInt(1,a.getAppointmentId());
            stat.setInt(2,a.getPatientId());
            stat.setInt(3,a.getDoctorId());
            stat.setString(4,a.getAppointmentDate());
            stat.setString(5,a.getDescription());
            if (stat.executeUpdate()>0)
            {
                System.out.println("Appointment SCHEDULED successfully!");
                return true;
            }
            else
            {
                System.out.println("Appointment schedule FAILED");
                return false;
            }
        } 
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateAppointment(Appointment a) 
    {
        try {
            PreparedStatement stat = con.prepareStatement(
                    "update Appointment set patientId=?, doctorId=?, appointmentDate=?, description=? where appointmentId=?");
            stat.setInt(1,a.getPatientId());
            stat.setInt(2,a.getDoctorId());
            stat.setString(3,a.getAppointmentDate());
            stat.setString(4,a.getDescription());
            stat.setInt(5,a.getAppointmentId());
            if(stat.executeUpdate()>0) 
            {
                System.out.println("Appointment UPDATED successfully!");
                return true;
            } 
            else
            {
                System.out.println("Invalid Appointment ID.Appointment UPDATE FAILED");
                return false;
            }
        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean cancelAppointment(int appointmentId)
    {
        try {
            PreparedStatement stat= con.prepareStatement("delete from Appointment where appointmentId=?");
            stat.setInt(1,appointmentId);
            if (stat.executeUpdate()>0) 
            {
                System.out.println("Appointment CANCELLED successfully!");
                return true;
            }
            else 
            {
                System.out.println("Invalid Appointment ID. Appointment CANCEL FAILED");
                return false;
            }
        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
        }
        return false;
    }
}
