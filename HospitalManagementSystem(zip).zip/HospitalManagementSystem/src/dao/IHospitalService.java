package dao;

import java.util.*;
import entity.*;
import exception.*;
public interface IHospitalService 
{
    Appointment getAppointmentById(int appointmentId);
    
    List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException;
    
    List<Appointment> getAppointmentsForDoctor(int doctorId);
    
    boolean scheduleAppointment(Appointment a);
    
    boolean updateAppointment(Appointment a);
    
    boolean cancelAppointment(int appointmentId);
}