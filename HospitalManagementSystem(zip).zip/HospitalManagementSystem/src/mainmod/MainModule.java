package mainmod;

import java.util.*;
import dao.*;
import entity.*;
import exception.*;
public class MainModule {
    public static void main(String[] args) throws PatientNumberNotFoundException {
        Scanner sc=new Scanner(System.in);
        IHospitalService ser=new HospitalServiceImpl();
        
        while (true)
        {
            System.out.println("Welcome to Hospital Management System");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule Appointment");
            System.out.println("5. Update Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            int c=sc.nextInt();

            switch(c) 
            {
                case 1:
                    System.out.println("You chose to get Appointment By ID ! ");
                    System.out.print("Enter Appointment ID: ");
                    int aID= sc.nextInt();
                    Appointment aps= ser.getAppointmentById(aID);
                    if(aps!= null) 
                    {
                    	System.out.println(aps);
                    }
                    break;

                case 2:
                    System.out.println("You chose to get Appointments For Patient ! ");
                    System.out.print("Enter Patient ID: ");
                    int pID = sc.nextInt();
                        List<Appointment> P_aps= ser.getAppointmentsForPatient(pID);
                        for (Appointment a: P_aps) 
                        {
                        	System.out.println(a);
                        }
                    
                    break;

                case 3:
                    System.out.print("Enter Doctor ID: ");
                    int dID = sc.nextInt();
                    List<Appointment> D_aps= ser.getAppointmentsForDoctor(dID);
                    for (Appointment a: D_aps) 
                    	{
                    	System.out.println(a);
                    	}
                    break;

                case 4:
                    System.out.print("Enter Appointment ID: ");
                    int newAid= sc.nextInt();
                    System.out.print("Enter Patient ID: ");
                    int newPid= sc.nextInt();
                    System.out.print("Enter Doctor ID: ");
                    int newDid= sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Appointment Date (yyyy-mm-dd): ");
                    String Adate = sc.nextLine();
                    System.out.print("Enter Description: ");
                    String dp= sc.nextLine();
                    Appointment nAps= new Appointment(newAid, newPid, newDid, Adate, dp);
                    ser.scheduleAppointment(nAps);
                    break;

                case 5:
                    System.out.print("Enter Appointment ID to Update: ");
                    int upAid= sc.nextInt();
                    System.out.print("Enter New Patient ID: ");
                    int upPid= sc.nextInt();
                    System.out.print("Enter New Doctor ID: ");
                    int upDid= sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Date in format(yyyy-mm-dd): ");
                    String upDate= sc.nextLine();
                    System.out.print("Enter New Description: ");
                    String upDp= sc.nextLine();
                    Appointment updApp = new Appointment(upAid, upPid, upDid, upDate, upDp);
                    ser.updateAppointment(updApp);
                    break;

                case 6:
                    System.out.print("Enter Appointment ID to Cancel: ");
                    int cancelAid= sc.nextInt();
                    ser.cancelAppointment(cancelAid);
                    break;

                case 7:
                    System.out.println("Exiting our Hospital Management System");
                    System.exit(0);

                default:
                    System.out.println("INVALID choice. Please enter a valid choice");
            }
        }
    }
}
