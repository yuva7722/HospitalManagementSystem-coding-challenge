package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {

    public static Connection getConnection()
    {
        Connection con = null;
        try {
           
            Properties p= PropertyUtil.loadProperties("resources/db.properties");
            String url= p.getProperty("url");         
            String user= p.getProperty("user");
            String pass= p.getProperty("password");
            con= DriverManager.getConnection(url, user, pass);
        } 
        catch (Exception e) 
        {
            System.out.println(e.getMessage()); 
        }
        return con;
    }
}